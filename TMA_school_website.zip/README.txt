# The Mervyn Academy Website

A responsive HTML/CSS/JavaScript school website based on the approved TMA homepage mockup.

## Files
- index.html — complete homepage
- styles.css — responsive design and components
- script.js — navigation, application modal, enquiry forms, gallery lightbox
- assets/tma-hero.png — generated visual used in the hero

## Run
Open `index.html` in a modern browser.

## Production setup
Replace:
1. Contact phone numbers and email addresses.
2. Parent Portal button destination.
3. Gallery placeholders with real school photographs.
4. Application/enquiry form JavaScript with a backend or form service.
5. Social-media links.
6. News and event data.

For a full production deployment, the next step would be to connect the site to the school's actual portal/CMS/database and add separate pages for About, Admissions, Academics, Student Life, News, Gallery and Contact.
