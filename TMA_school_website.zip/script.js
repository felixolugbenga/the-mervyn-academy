const nav = document.getElementById("nav");
const menuToggle = document.querySelector(".menu-toggle");
menuToggle.addEventListener("click", () => nav.classList.toggle("open"));
document.querySelectorAll(".nav a").forEach(a => a.addEventListener("click", () => nav.classList.remove("open")));

const modal = document.getElementById("modal");
const openModal = () => { modal.classList.add("show"); modal.setAttribute("aria-hidden","false"); };
const closeModal = () => { modal.classList.remove("show"); modal.setAttribute("aria-hidden","true"); };
document.getElementById("applyBtn").addEventListener("click", openModal);
document.getElementById("portalBtn").addEventListener("click", () => {
  alert("Parent Portal\n\nConnect this button to your live school management/parent portal URL.");
});
document.getElementById("closeModal").addEventListener("click", closeModal);
modal.addEventListener("click", e => { if(e.target === modal) closeModal(); });

document.getElementById("admissionForm").addEventListener("submit", e => {
  e.preventDefault();
  document.getElementById("admissionMessage").textContent = "Thank you. Your application enquiry has been received.";
  e.target.reset();
});

document.getElementById("contactForm").addEventListener("submit", e => {
  e.preventDefault();
  document.getElementById("formMessage").textContent = "Thank you. Your enquiry has been submitted successfully.";
  e.target.reset();
});

const lightbox = document.getElementById("lightbox");
const lbImage = document.getElementById("lightboxImage");
const lbTitle = document.getElementById("lightboxTitle");
document.querySelectorAll(".gallery-item").forEach(item => {
  item.addEventListener("click", () => {
    lbImage.className = "lightbox-image " + item.className.replace("gallery-item ","");
    lbTitle.textContent = item.dataset.title;
    lightbox.classList.add("show");
  });
});
document.getElementById("closeLightbox").addEventListener("click", () => lightbox.classList.remove("show"));
lightbox.addEventListener("click", e => { if(e.target === lightbox) lightbox.classList.remove("show"); });

const sections = [...document.querySelectorAll("main section[id]")];
const links = [...document.querySelectorAll(".nav a")];
const observer = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if(entry.isIntersecting){
      links.forEach(link => link.classList.toggle("active", link.getAttribute("href") === "#" + entry.target.id));
    }
  });
}, {rootMargin:"-35% 0px -55% 0px"});
sections.forEach(s => observer.observe(s));

document.querySelectorAll('a[href="#"]').forEach(a => a.addEventListener("click", e => e.preventDefault()));
